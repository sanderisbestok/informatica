Sadly the results I got (the graph) are wrong. They are not comparable with
any of the results I could find on the internet. I tested it with different
configurations the results.png is with k=3 r=2. Sadly I could not find out
where I did go wrong. Both the random table and table walk through seem to work
good (when calculating average appearance).

I spend a long time trying to fix the graph, therefor I did not do many
experiments.
