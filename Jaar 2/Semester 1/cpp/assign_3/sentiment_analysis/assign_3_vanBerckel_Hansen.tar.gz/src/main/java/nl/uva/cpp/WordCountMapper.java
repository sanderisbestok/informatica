package nl.uva.cpp;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

import me.champeau.ld.UberLanguageDetector ;

import java.util.Properties ;
import edu.stanford.nlp.ling.CoreAnnotations ;
import edu.stanford.nlp.pipeline.Annotation ;
import edu.stanford.nlp.pipeline.StanfordCoreNLP ;
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations ;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations ;
import edu.stanford.nlp.trees.Tree ;
import edu.stanford.nlp.util.CoreMap;

public class WordCountMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	String parseModelPath = "englishPCFG.ser.gz";
	String sentimentModelPath = "sentiment.ser.gz";
	Properties props = new Properties();
	StanfordCoreNLP pipeline;

	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();

	static enum Counters {
		INPUT_WORDS
	}

	public WordCountMapper(){
		props.setProperty("annotators", "tokenize, ssplit, parse, sentiment");
		props.put("parse.model", parseModelPath);
		props.put("sentiment.model", sentimentModelPath);
		pipeline = new StanfordCoreNLP (props);
	}

	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String line = value.toString().toLowerCase();
		String[] text;
		String tweet;

		/* Extract text of the tweet */
		text = line.split("\n");
		tweet = text[2].substring(1);

		StringTokenizer itr = new StringTokenizer(tweet);

		int count = 0;
		while (itr.hasMoreTokens()) {
			/* Obtain the next word. */
			String token = itr.nextToken();

			/* Check if the word is hashtag */
			if (token.startsWith("#")) {
				/* Detect language of tweet */
				String lang = UberLanguageDetector.getInstance().detectLang(tweet);

				/* If the language is English calculate the sentiment */
				if (lang == "en") {
					int sentiment = findSentiment(tweet);

					/* Write (word, 1) as (key, value) in output */
					word.set(token);
					context.write(word, new IntWritable(sentiment));
				}

				/* Increment a counter. */
				context.getCounter(Counters.INPUT_WORDS).increment(1);
			}
		}
	}

	/* Find the sentiment of a given string */
	private int findSentiment(String text) {
		int mainSentiment = 0;

		if (text != null && text.length() > 0) {
			int longest = 0;
			Annotation annotation = pipeline . process ( text );

			for (CoreMap sentence : annotation.get(CoreAnnotations.SentencesAnnotation.class)) {
				// ’ AnnotatedTree ’ is ’ SentimentAnnotatedTree ’ in newer versions
				Tree tree = sentence.get(SentimentCoreAnnotations.AnnotatedTree.class);
				int sentiment = RNNCoreAnnotations.getPredictedClass(tree);
				String partText = sentence.toString();
				if (partText.length() > longest) {
					mainSentiment = sentiment ;
					longest = partText.length () ;
				}
			}
		}
		return mainSentiment ;
	}
}
