package nl.uva.cpp;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

public class WordCountReducer extends Reducer<Text, IntWritable, Text, Text> {

	@Override
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {
		int sum = 0;
		int count = 0;
		double sd, mean;

		ArrayList<Integer> valuearray = new ArrayList<Integer>();

		for (IntWritable val : values) {
			valuearray.add(val.get());
			sum += val.get();
			count++;
		}

		/* Calculate mean */
		mean = (double)sum / (double)count;

		sd = 0;
		count = 0;

		/* Calculate standard deviation */
		for (int val : valuearray) {
			sd = sd + Math.pow(valuearray.get(count) - mean, 2);
			count++;
		}

		sd = sd / count;
		sd = Math.sqrt(sd);

		String value = String.valueOf(count) + "\t" + String.valueOf(mean) + "\t" + String.valueOf(sd);
		context.write(key, new Text(value));
	}
}
