"""
Lab 2 - HTTP Server
NAME: Sander Hansen
STUDENT ID: 10995080
DESCRIPTION: Test page for CGI
"""


def get_content():
    content = """
        <html>
            <head>
                <title>CGI TEST PAGE</title>
            </head>
            <body>
                <h1> CGI Test Page </h1>
    """
    content += "DOCUMENT_ROOT: " + sys.argv[1] + "<br>"
    content += "REQUEST_METHOD: " + sys.argv[2] + "<br>"
    content += "REQUEST_URI: " + sys.argv[3] + "<br>"
    if sys.argv[4] == "":
        content += "QUERY_STRING: No query string given <br>"
    else:
        content += "QUERY_STRING: " + sys.argv[4] + "<br>"

    content += "PATH: " + sys.argv[5] + "<br>"
    content += "REMOTE_ADDR: " + sys.argv[6] + "<br>"

    content += """
            </body>
        </html>
    """

    return content


# Content-Type is hardcoded because we know it is HTML (Everything is hardcoded)
def make_header(content):
    content_length = len(content)
    header = "Connection: close\r\n"
    header += "Content-Type: text/html\r\n"
    header += "Content-Length: " + str(content_length) + "\r\n"
    header += "Server: Sherrif's Crib\r\n\r\n"

    return header


if __name__ == '__main__':
    import sys

    content = get_content()
    header = make_header(content)

    print header + content
