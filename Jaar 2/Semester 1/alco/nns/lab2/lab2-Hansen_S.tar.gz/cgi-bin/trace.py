"""
Lab 2 - HTTP Server
NAME: Sander Hansen
STUDENT ID: 10995080
DESCRIPTION: Tracerouting page for HTTP Server
"""

def get_content():
    content = """
        <html>
            <head>
                <title>Traceroute</title>
            </head>
            <body>
                <h1>Tracerouting</h1>
                <p>
    """

    get_ip = sys.argv[4]

    if get_ip.startswith("ip="):
        ip = get_ip.split("=", 1)[1]
        print ip
        cgi = subprocess.Popen(["traceroute", ip], stdout=subprocess.PIPE)
        traceroute = cgi.communicate()[0].replace("\n", "<br>")

        if traceroute == "":
            content += "Something went wrong while tracerouting.</p>"
        else:
            content += traceroute + "</p>"
    else:
        content += """
            <p>ERROR: Please enter the IP as Query String following this format:
            <br>
                <b>localhost:8080/cgi-bin/trace.py?ip=YOURIPHERE</b>
            </p>
        """

    content += """
            </body>
        </html>
    """

    return content


# Content-Type is hardcoded because we know it is HTML (Everything is hardcoded)
def make_header(content):
    content_length = len(content)
    header = "Connection: close\r\n"
    header += "Content-Type: text/html\r\n"
    header += "Content-Length: " + str(content_length) + "\r\n"
    header += "Server: Sherrif's Crib\r\n\r\n"

    return header

if __name__ == '__main__':
    import sys
    import subprocess

    content = get_content()
    header = make_header(content)

    print header + content
