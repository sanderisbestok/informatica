Samenstelling projectgroep;

Jens Kalshoven:   11026243
Pim Hordijk:      10707301
Sander Hansen:    10995080
Rico Hoegee:      10707301
Frederick Kreuk:  11020997

URL;

https://www.stuffz.nl

Inloggegevens;

Een normaal account kan aangemaakt worden door te registreren.
Het volgende account heeft alle rechten;
Gebruikersnaam: admin@swatman.nl
Wachtwoord:     swatman123

Bronvermelding;
In de laatste sectie van het technisch rapport is de bronvermelding te vinden. 
