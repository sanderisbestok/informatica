<?php
  function maakFactuur($order_id) {
    $session_id = session_id();
    shell_exec("wkhtmltopdf https://www.stuffz.nl/factuur.php?order_id=$order_id ./facturen/factuur$order_id.pdf");
  }
?>
