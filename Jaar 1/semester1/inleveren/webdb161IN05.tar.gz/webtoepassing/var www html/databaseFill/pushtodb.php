<?php
include_once('../globalUI/globalConnect.php');

$jsondata = file_get_contents("categories.json");
$json = json_decode($jsondata,true);
foreach($json['categories'] as $category) {
  //how to use json array to insert data in Database
  $stmt = $globalDB->prepare("INSERT INTO categories (category_name) VALUES (:groep)");
  $stmt->bindParam(':groep', $category['groep']);
  $stmt->execute();
}

$i=0;
$jsondata = file_get_contents("products.json");
$json = json_decode($jsondata,true);
foreach($json['products'] as $product) {
  //how to use json array to insert data in Database

  $i=$i+1;
  $stmt = $globalDB->prepare("SELECT category_id FROM categories WHERE category_name = :category_name");
  $stmt->bindParam(':category_name', $product['category_name']);
  $stmt->execute();

  $category_id = $stmt->fetch(PDO::FETCH_NUM);

  $stmt = $globalDB->prepare("INSERT INTO products (serial_number,name,description,category_id,supply) VALUES (:serial_number,:name,:description,:category_id,:supply)");
  $stmt->bindParam(':serial_number', $product['serial_number']);
  $stmt->bindParam(':name', $product['name']);
  $stmt->bindParam(':description', $product['description']);
  $stmt->bindParam(':category_id', $category_id[0]);
  $stmt->bindParam(':supply', $product['supply']);
  $stmt->execute();

  $stmt = $globalDB->prepare("INSERT INTO media (path, name) VALUES (:path,:name)");
  $stmt->bindValue(':path','resources/products/' .  $i . '.jpg');
  $stmt->bindParam(':name', $product['name']);
  $stmt->execute();

  $stmt = $globalDB->prepare("SELECT product_id FROM products WHERE name = :name");
  $stmt->bindParam(':name', $product['name']);
  $stmt->execute();

  $product_id = $stmt->fetch(PDO::FETCH_NUM);

  $stmt = $globalDB->prepare("SELECT media_id FROM media WHERE name = :name");
  $stmt->bindParam(':name', $product['name']);
  $stmt->execute();

  $media_id = $stmt->fetch(PDO::FETCH_NUM);

  $stmt = $globalDB->prepare("INSERT INTO products_media VALUES (:product_id,:media_id)");
  $stmt->bindParam(':product_id', $product_id[0]);
  $stmt->bindParam(':media_id', $media_id[0]);
  $stmt->execute();

  $stmt = $globalDB->prepare("INSERT INTO prices (price, product_id) VALUES (:price,:product_id)");
  $stmt->bindValue(':price',$product['atomicmass']);
  $stmt->bindParam(':product_id', $product_id[0]);
  $stmt->execute();
}

$jsondata = file_get_contents("features.json");
$json = json_decode($jsondata,true);
foreach($json['features'] as $feature) {
  /* Fetch product_id corresponding to serial_number from products */
  $stmt = $globalDB->prepare("SELECT product_id FROM products WHERE serial_number = :serial_number");
  $stmt->bindParam(':serial_number', $feature['serial_number']);
  try{
    $stmt->execute();
  } catch(PDOException $e) {
    $errorCode = $stmt->errorInfo()[1];
    if($errorCode == 1062) {

    }
  }

  $product_id = ($stmt->fetch(PDO::FETCH_NUM))[0];

  /* Fetch the spec id based on name if exists, or create and fetch it if it doesn't. */
  $stmt = $globalDB->prepare("INSERT INTO specs (spec_name)
    SELECT :spec_name AS spec_name
    FROM dual
    WHERE NOT EXISTS
    ( SELECT *
    FROM specs
    WHERE spec_name = :spec_name
  );");
  $stmt->bindParam(':spec_name', $feature['feature_name']);
  $stmt->execute();

  $stmt = $globalDB->prepare("SELECT * FROM specs
    WHERE spec_name = :spec_name;");
  $stmt->bindParam(':spec_name', $feature['feature_name']);
  $stmt->execute();
  $spec_info = $stmt->fetch(PDO::FETCH_ASSOC);
  $spec_id = $spec_info['spec_id'];
  echo("spec_id:");
  echo($spec_id);

  /* Insert spec value into spec_values */
  $stmt = $globalDB->prepare("INSERT INTO spec_values (value_char) VALUES (:spec_value);");
  $stmt->bindParam(':spec_value', $feature['feature_value']);
  $stmt->execute();
  $value_id = $globalDB->lastInsertId();

  /* Link product to spec and value */
  $stmt = $globalDB->prepare("INSERT INTO products_specs (product_id, spec_id, value_id) VALUES (:product_id, :spec_id, :value_id);");
  $stmt->bindParam(':product_id', $product_id);
  $stmt->bindParam(':spec_id', $spec_id);
  $stmt->bindParam(':value_id', $value_id);
  $stmt->execute();
}
?>
