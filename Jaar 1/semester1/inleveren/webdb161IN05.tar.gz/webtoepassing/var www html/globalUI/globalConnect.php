<?php
/*
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         globalConnect.php
Description;  Sets up session and database connection. Required for practically
              all pages.
Usage;        include_once([FILEPATH]);
*/
  /* Start session */
  if (session_status() == PHP_SESSION_NONE){
    session_start();
    /* Update last_visited only if the request is from running script, not miscellaneous requests */
    if(substr($_SERVER["REQUEST_URI"], 0, strlen($_SERVER["REQUEST_URI"])) === $_SERVER["PHP_SELF"]){
      if(isset($_SESSION["current"])){
          $_SESSION["last_visited"] = $_SESSION["current"];
        } else {
          $_SESSION["last_visited"] = "index.php";
        }
      $_SESSION["current"] = htmlspecialchars(preg_replace('/^.*\/\s*/', '', $_SERVER["REQUEST_URI"]));
    }
  }

  /* Specify database connection parameters */
  $db_server = "localhost";
  $db_name = "stuffz";
  $db_user = "user";
  $db_passwd = "H2jSSaUFNyHLbS7h";

  /* Connect to database */
  try{
    $globalDB = new PDO("mysql:host=$db_server;dbname=$db_name",$db_user,$db_passwd);
    $globalDB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch(PDOException $e) {
      die("Error connecting to database.");
  }

?>
