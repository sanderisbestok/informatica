<!--
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         footer.php
Description;  Footer for inclusion in other pages
Usage;        include();
-->
<div id="footerContainer">
  <div id="footer">
    <div class="row footerContent">
        <div class="footerElement odd c-3">
          <span class="head">Contact</span>
          <ul>
            <li><a href="mailto:Sanderhansen20@hotmail.com">Sander Hansen</a></li>
            <li><a href="mailto:jens.k@live.nl">Jens Kalshoven</a></li>
            <li><a href="mailto:rick.advertisements@icloud.com">Pim Hordijk</a></li>
            <li><a href="mailto:ricotlfm@gmail.com">Rico Hoegee</a></li>
            <li><a href="mailto:rick.advertisements@icloud.com">Frederick Kreuk</a></li>
          </ul>
        </div>
        <div class="footerElement even c-3">
          <span class="head">Over Stuffz</span>
          Stuffz is opgezet in 2016 om een centrale plek te vormen voor al uw
          elementaire benodigdheden.
        </div>
        <div class="footerElement odd c-3">
          <span class="head">Legal</span>
          Copyright Stuffz&trade; 2016-2016. Foto's van elementen zijn verkregen
          van <a href="http://images-of-elements.com/">images-of-elements</a> onder
          de Creative Commons Attribution 3.0 Unported License. Informatie van elementen is
          afkomstig van <a href="http://www.wikipedia.nl">Wikipedia</a> onder de GNU Free Documentation License.
        </div>
        <div class="footerElement even c-3">
          <span class="head">Colofon</span>
          Deze webpagina is ontworpen door Sander Hansen, Pim Hordijk, Rico
          Hoegee, Jens Kalshoven en Frederick Kreuk in opdracht van de UvA.
        </div>
      </div>
    </div>
  </div>
</div>
