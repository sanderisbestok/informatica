<!--
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         globalReqs.php
Description;  Specifies files required in all files.
Usage;        include_once([FILEPATH]);
-->

<link rel="stylesheet" href="style/global.css" />
<!--<link rel="stylesheet" href="style/globalUI.css" />-->
<link rel="stylesheet" href="style/buttons.css" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0" />
<script src="scripts/jquery-1.11.3.min.js"></script>
<script src="./scripts/global.js"></script>
<!--<script src="./scripts/globalUI.js"></script>-->
<meta charset="UTF-8" />
<link rel="shortcut icon" href="resources/favicon/favicon.ico" type="image/x-icon">
<link rel="icon" href="resources/favicon/favicon.ico" type="image/x-icon">
