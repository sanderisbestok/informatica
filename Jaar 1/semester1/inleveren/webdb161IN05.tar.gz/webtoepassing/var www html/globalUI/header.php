<!--
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         header.php
Description;  Header for inclusion in other pages
Usage;        include([FILEPATH]);
-->
<?php
  include_once('globalUI/globalConnect.php');

  include_once('stools/cartTools.php');

  /* Fetch information about current user if logged in and set privilege_level */
  if(!empty($_SESSION["user_id"])){
    $user_id = $_SESSION["user_id"];

    $stmt = $globalDB->prepare("SELECT first_name, surname, prefix, privilege_level
                                  FROM users
                                  WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $results = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $result = $stmt->fetch();

    /* Place results in easy-to-use variables */
    $user_first_name = $result["first_name"];
    $user_surname = $result["surname"];
    $user_prefix =  $result["prefix"];
    $privlevel = $result["privilege_level"];

    /* Either assert login success or login failure. In case of failure, set
      privilege level to standard user (0) */
    $user_didLogin = TRUE;
  } else {
    $user_didLogin = FALSE;
    $privlevel = 0;
  }

  /* Place cart from session in variable if exists or create cart */
  $cart_empty = TRUE;
  if(!isset($_SESSION["cart"])) {
    $_SESSION["cart"] = array();
  } else {
    if(count($_SESSION["cart"]) > 0) {
      $cart_empty = FALSE;
      $cart = getCart($_SESSION["cart"]);
    }
  }

  /* Function loginLogout prints html login/logout button based on current login
     status */
  function loginLogout(){
    global $user_didLogin, $user_first_name, $user_prefix, $user_surname;
    if($user_didLogin){
      print("
      <li>
        <a href='logout.php?redirect=index.php'>
          <div class='actionElem popOItem login'>
            <span class='popListIText'>
              ".$user_first_name." ".$user_prefix." ".$user_surname." afmelden
            </span>
          </div>
        </a>
      </li>
      ");
    } else {
      print("
      <li>
        <a href='inlogpagina.php?redirect=".$_SERVER['REQUEST_URI']."'>
          <div class='actionElem popOItem login'>
            <span class='popListIText'>
              Aanmelden
            </span>
          </div>
        </a>
      </li>
      ");
    }
  }
?>

<!-- Include script cart.js for popCart updating -->
<script src="scripts/cart.js"></script>

<!-- Begin actual navigation bar -->
<div id="navBar" class="floatingNavContainer">
  <div class="nav">
    <!-- Logo. Separate versions for desktop, tablet and mobile -->
    <div class="ch-3">
      <a href="index.php">
        <img src="resources/logo_temp2.svg" onerror="resources/logo_temp2.png" id="navLogo" />
      </a>
      <a href="index.php">
        <img src="resources/logo_temp2_HM.svg" onerror="resources/logo_temp2.png" id="navLogoHM" />
      </a>
      <a href="index.php">
        <img src="resources/logo_temp2_M.svg" onerror="resources/logo_temp2.png" id="navLogoM" />
      </a>
    </div>
    <!-- Category button. Opens category popOver -->
    <div class="navButtonW ch-1">
      <a class="noJSButton" href="cat.php">
        <div id="catButton" class="navButton navButtonB" onclick="openPopOver('cat')">
          <img id="catChevron" class="navChevron" src="./resources/chevron.png" />
        </div>
      </a>
    </div>
    <!-- Spacer -->
    <div class="ch-3">
    </div>

    <!-- Include search script for dynamic input completion on search bar -->
    <script src="scripts/search.js"></script>

    <!-- Search button. Opens mobile search view -->
    <div class="navButtonW ch-3">
        <div id="searchButton" class="navButton navButtonB"
             onclick="openPopOver('searchM')">
        </div>
      <form method="get" action="zoeken.php?go">
        <input type="text" class="navSearch" name="q"
               onkeyup="openPopOver('search'), getProd(this.value)"
               placeholder="zoek element"/>
      </form>
      <div id="searchPopup" class="popOver">
        <ul class="searchProd"></ul>
      </div>
    </div>

    <!-- User button. Opens cart and user popOver -->
    <div class="navButtonW ch-2">
      <!-- Link to dedicated cart page for users without javascript -->
      <a class="noJSButton" href="cart.php">
        <div id="userButton" class="navButton navButtonB"
                  onclick="updateSmallCart('popCart'); openPopOver('user')">
          <img id="userChevron" class="navChevron" src="./resources/chevron.png" />
        </div>
      </a>
    </div>

    <div id="catPopup" class="popOver">
      <ul>
       <!-- Generate list of categories -->
      <?php
      /* Fetch categories from database */
      $stmt = $globalDB->prepare('SELECT category_id, category_name
                                  FROM categories ORDER BY category_id');
      $stmt->execute();

      $product_category = $stmt->fetchAll(PDO::FETCH_ASSOC);

      /* Echo categories in list */
      foreach($product_category as $i) {
        $categories=$i["category_id"];
        $category_name=$i["category_name"];
        echo "<li>
                <a href=categorieen.php?category_id=$categories>
                  <div class='categoryListing actionElem'>$category_name</div>
                </a>
              </li>";
      }
      ?>
      </ul>
    </div>
  </div>

  <!-- Mobile search popup -->
  <div id="searchMPopup" class="popOver mobile noJSMSearch">
    <div class="row">
      <form class="ch-12" method="get" action="zoeken.php?go">
        <input type="text" class="navSearch" name="q"
               onkeyup="getProd(this.value)" placeholder="zoek element" />
      </form>
    </div>
    <div class="row">
      <ul class="searchProd" id="searchProdM"></ul>
    </div>
  </div>
  <div id="userPopup" class="popOver">
    <div id="popCart">
      <ul class="popCart">
      <?php
          /* Generate header cart view. genHCart() from cartTools */
          genHCart();
       ?>
     </ul>
     </div>
     <!-- Options in cart view -->
     <div class="popOptions">
         <ul class="popOList">
             <li>
          <a href="winkelwagen.php">
            <div class="actionElem popOItem cart">
              <span class="popListIText">Winkelwagen</span>
            </div>
          </a>
        </li>
        <?php
          if($user_didLogin){
            echo"
            <li>
              <a href='orderhistorie.php'>
                <div class='actionElem popOItem hist'>
                  <span class='popListIText'>Bestellingen</span>
                </div>
              </a>
            </li>";
          }
        ?>
        <?php
          if($user_didLogin){
            echo "
            <li>
              <a href='gebruiker.php'>
                <div class='actionElem popOItem acc'>
                  <span class='popListIText'>Account</span>
                </div>
              </a>
            </li>";
          }
          if(intval($privlevel) > 0){
            echo "
              <li><a href='admin.php'>
                <div class='actionElem popOItem acc'>
                  <span class='popListIText'>Admin</span>
                </div>
              </a></li>";
          }
        ?>
        <?php loginLogout(); ?>
      </ul>
    </div>
  </div>
</div>
