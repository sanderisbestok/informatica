<?php
session_start();

$product = $_POST["addtocart"];
$redirect = $_GET["redirect"];

function addtocart($product){
  $_SESSION["cart"][$product]["id"] = $product;
  $_SESSION["cart"][$product]["amount"] = $_SESSION["cart"][$product]["amount"] + 1;
  $_SESSION["justAdded"] = TRUE;
}

addtocart($product);
if(isset($_GET["redirect"])){
  header("Location: $redirect");
}
?>
