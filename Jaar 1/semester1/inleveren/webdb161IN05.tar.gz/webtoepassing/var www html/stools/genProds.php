<!--
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         genProds.php
Description;  Select every info needed for certain product
Usage;        n/a
-->
<?php
  echo "
    <a href='product.php?product_id=$product[product_id]'>
      <div class='listing-product'>
        <h3>$product[name]</h3>
        <img src='$product[path]' alt='$product[alt]'>
        <p class='listing-price'>&euro;$price[price_eur],$price[price_cent]</p>
  ";
  if ($product['supply'] > 0) {
    echo "
      <form action='./stools/addtocart.php?redirect=$_SERVER[PHP_SELF]?$parameter' method='post'>
        <div class='bbWrap'>
    ";

          /* Show notifcation when adding item to basket */
          $inCart = inCart($product['product_id']);

          if ($inCart > 0) {
            echo "
              <div class='compositeButton'>
                <button type='submit' name='addtocart' class='green start' value='$product[product_id]'>Voeg toe</button>
                <a href='winkelwagen.php' class='green end incart' value='$product[product_id]'>$inCart</button></a>
              </div>
            ";
          } else {
            echo "
              <button type='submit' name='addtocart' class='addtocart' value='$product[product_id]'>Voeg toe</button>
            ";
          }
          echo"
            </div>
          </form>
          ";
    }

    /* Check if product is in stock*/
    if ($product['supply'] <= 0) {
      echo "
        <p class='listing-not-in-stock'>Niet op voorraad</p>
      ";
    } else {
      echo "
        <p class='listing-stock'>Op voorraad</p>
      ";
    }
    echo "
        </div>
      </a>
    ";
?>
