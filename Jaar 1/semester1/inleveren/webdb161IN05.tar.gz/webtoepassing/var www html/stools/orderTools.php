<!--
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         orderTools.php
Description;  Functions for pages which need information about an order
Usage;        functionname($variable);
-->
<?php
  if(is_readable("../globalUI/globalConnect.php")){
    include_once("../globalUI/globalConnect.php");
    include_once("cartTools.php");
  } else if(is_readable("globalUI/globalConnect.php")){
    include_once("globalUI/globalConnect.php");
  }

  $orderStates = array('pay'=>'Betalen', 'prep'=>'Voorbereiden', 'preps'=>'Zending voorbereiden', 'sent'=>'Verzonden', 'del'=>'Afgeleverd', 'canc'=>'Geannuleerd');

  /* Function will get all orders from a certain user */
  function getOrders($user_id){
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT order_id, date
                                  FROM orders
                                WHERE user_id = :user_id
                                 ORDER BY date DESC");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $orders;
  }

  /* Function will get information from a certain order*/
  function getOrder($order_id){
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT date, products_orders.amount as amount, prices.price as price, state as state, tax_rate as tax_rate, user_id as user_id
                                  FROM orders
                                INNER JOIN products_orders
                                  ON orders.order_id = products_orders.order_id
                                INNER JOIN prices
                                  ON products_orders.price_id = prices.price_id
                                WHERE products_orders.order_id = :order_id");
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();
    $order_info = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $new_order_info['amount'] = 0;
    $new_order_info['price'] = 0;
    $new_order_info['tax_rate'] = $order_info[0]['tax_rate'];
    $new_order_info['user_id'] = $order_info[0]['user_id'];
    foreach($order_info as $sub_order_info) {
      $new_order_info['amount'] = $new_order_info['amount'] + $sub_order_info['amount'];
      $new_order_info['price'] = $new_order_info['price'] + $sub_order_info['amount'] * $sub_order_info['price'];
    }

    $mysql_date = strtotime($order_info[0]['date']);
    $new_order_info['date'] = date("d-m-Y", $mysql_date);
    $new_order_info['raw_state'] = $order_info[0]['state'];
    $new_order_info['state'] = getOrderStatus($order_info[0]['state']);
    $new_order_info['canbecanceled'] = canOrderBeCanceled($order_info[0]['state']);

    return $new_order_info;
  }

  /* Function will convert order state to string*/
  function getOrderStatus($status) {
    if ($status == "pay") {
      $new_status = "Betalen";
    } elseif ($status == "prep") {
      $new_status = "Voorbereiden";
    } elseif ($status == "preps") {
      $new_status = "Voorbereiden voor verzending";
    } elseif ($status == "sent") {
      $new_status = "Verzonden";
    } elseif ($status == "del") {
      $new_status = "Afgeleverd";
    } elseif ($status == "canc") {
      $new_status = "Geannuleerd";
    }

    return $new_status;
  }

  /* Function returns boolean if an order can be canceled */
  function canOrderBeCanceled($status) {
      if ($status == "pay" || $status == "prep" || $status == "preps") {
          return TRUE;
      } else {
          return FALSE;
      }
  }

  /* Function returns products with a certain order_id */
  function getOrderProducts($order_id){
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT product_id
                                  FROM products_orders
                                WHERE order_id = :order_id");
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $orders;
  }

  /* Function that will return the price and amount of a certain product in a certain order */
  function getOrderProductAmount($product_id, $order_id){
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT amount, prices.price as price
                                  FROM products_orders
                                INNER JOIN prices
                                  ON products_orders.price_id = prices.price_id
                                WHERE products_orders.product_id = :product_id
                                  AND order_id = :order_id");
    $stmt->bindParam(':product_id', $product_id);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();

    $product_amount = $stmt->fetch(PDO::FETCH_ASSOC);

    $product_amount['price'] = $product_amount['amount'] * $product_amount['price'];

    return $product_amount;
  }

  /* Function checks if order is from the current user*/
  function userCheck($user_id, $order_id) {
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT order_id
                                  FROM orders
                                WHERE user_id = :user_id
                                  AND order_id = :order_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();

    $userCheck = $stmt->fetch(PDO::FETCH_ASSOC);

    if(empty($userCheck)) {
      return TRUE;
    } else {
      return FALSE;
    }
  }

  /* function that will get only some 'short' info of user*/
  function getShortUser($user_id) {
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT sex, first_name, prefix, surname
                                  FROM users
                                  WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if($user["sex"] = "male") {
      $info["title"] = "Dhr.";
    } else if($user["sex"] = "female") {
      $info["title"] = "Mvr.";
    } else {
      $info["title"] = "";
    }
    $words = preg_split("/\s+/", $user["first_name"]);
    $info["initials"] = "";
    foreach($words as $w) {
      $info["initials"] .= $w[0].".";
    }
    $info = array_merge($info, $user);
    return $info;
  }

/* Interface for legacy cancel order function calls */
/* Function that will cancel an order and add the amount of canceled products back to the supply */
function changeOrderStatus($order_id) {
  changeOrderStatusSelect($order_id, "canc");
}

function changeOrderStatusSelect($order_id, $new_status) {
  global $globalDB;
  $stmt = $globalDB->prepare("UPDATE orders
                                SET state = :state
                              WHERE order_id = :order_id
                              LIMIT 1");

  $stmt->bindParam(':state', $new_status);
  $stmt->bindParam(':order_id', $order_id);
  $stmt->execute();

  if($new_status == "canc" && canOrderBeCanceled($order_id)) {
    $order_products = getOrderProducts($order_id);

    foreach ($order_products as $order_product) {
      $stmt = $globalDB->prepare("UPDATE products
                                 INNER JOIN products_orders
                                  ON :product_id = products_orders.product_id
                                 SET supply = supply + products_orders.amount
                                 WHERE products.product_id = :product_id");

      $stmt->bindParam(':product_id', $order_product['product_id']);
      $stmt->execute();
    }
  }
}

  /* Get adress of an order */
  function getAddress($order_id) {
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT address_id
                                  FROM orders
                                WHERE order_id = :order_id");
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();
    $address_id = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $globalDB->prepare("SELECT street, number, addition, postcode, city
                                  FROM addresses
                                WHERE address_id = :address_id");
    $stmt->bindParam(':address_id', $address_id['address_id']);
    $stmt->execute();
    $address = $stmt->fetch(PDO::FETCH_ASSOC);

    return $address;
  }

  /* Get name of an order */
  function getName($order_id) {
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT user_id
                                  FROM orders
                                WHERE order_id = :order_id");
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();
    $user_id = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $globalDB->prepare("SELECT first_name, surname, prefix
                                  FROM users
                                WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $user_id['user_id']);
    $stmt->execute();
    $name = $stmt->fetch(PDO::FETCH_ASSOC);

    return $name;
  }

    if(isset($_POST["redirect"])) {
      $redirect = $_POST["redirect"];
      header("Location: $redirect");
    }

  /* Functions for searching */
  function getOrderSearch($search, $stateArray){
      global $globalDB;
      $search = "%".$search."%";
      $states = "(";
      $params = array();
      $params[] = $search;
      foreach($stateArray as $state=>$value) {
        if($value == "true"){
          $states .= $state.",";
          $params[] = $state;
        }
      }
      $states = rtrim($states, ",");
      $states .= ")";
      if(count($params) > 2) {
        $placeholders = str_repeat ("? OR orders.state LIKE ",  count ($params) - 2) . "?";
      } else if (count($params) == 2) {
        $placeholders = "?";
      } else {
        $placeholders = "'%'";
      }
      $getOrders = "SELECT order_id FROM orders INNER JOIN users ON users.user_id = orders.user_id WHERE users.surname LIKE ? AND orders.state LIKE $placeholders ORDER BY orders.date DESC";
      $stmtOrders = $globalDB->prepare($getOrders);
      //$stmtOrders->bindParam(':search', $search);
      //$stmtOrders->bindParam(':states', $states);
      $stmtOrders->execute($params);
      $orders = $stmtOrders->fetchAll(PDO::FETCH_ASSOC);
      $orderinfo = array();
      foreach($orders as $order){
        $orderinfo[$order["order_id"]] = getOrder($order["order_id"]);
      }
      return $orderinfo;
  }

  function generateOrders($orders){
      if(count($orders) <= 0) {
        return "";
      }
      $result = "";
      foreach($orders as $orderId => $order){
        $tax = $order["tax_rate"];
        $amount = $order["amount"];
        $date = $order["date"];
        $price = calculatePrice($order["price"]);
        $user = getShortUser($order["user_id"]);
        $state = $order["state"];

        $result .= "
          <tr class='table-row' onclick=window.location.href='adminorderdetail.php?order_id=".$orderId."'>
            <td data-label=Bestelnummer>".$orderId."</td>
            <td data-label=Belasting>".$tax."</td>
            <td data-label=Aantal>".$amount."</td>
            <td data-label=Prijs>&euro;".$price["price_eur"].",".$price["price_cent"]."</td>
            <td data-label=Datum>".$date."</td>
            <td data-label=Status>".$state."</td>
            <td data-label=Gebruiker>".$user["title"]." ".$user["initials"]." ".$user["surname"]."</td>
          </tr>
        ";
      }
      return $result;
  }

  /* Switch for AJAX requests */
  if(isset($_POST["action"])){
    switch($_POST["action"]){
      case "generateAll":
        generateAll();
        break;
      case "searchAdminOrders":
        if(isset($_POST["search"])){
          $search = $_POST["search"];
          $stage["pay"] = $_POST["pay"];
          $stage["prep"] = $_POST["prep"];
          $stage["preps"] = $_POST["preps"];
          $stage["sent"] = $_POST["sent"];
          $stage["del"] = $_POST["del"];
          $stage["canc"] = $_POST["canc"];
          $orders = getOrderSearch($search, $stage);
          print generateOrders($orders);
          break;
        }
    }
  }
