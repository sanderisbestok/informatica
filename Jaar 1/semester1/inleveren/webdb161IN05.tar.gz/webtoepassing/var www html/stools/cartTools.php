<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);

  if (session_status() == PHP_SESSION_NONE){
    session_start();
    if(is_readable("../globalUI/globalConnect.php")){
      include_once("../globalUI/globalConnect.php");
    } else if(is_readable("globalUI/globalConnect.php")){
      include_once("globalUI/globalConnect.php");
    }
  }

  $cart_empty = TRUE;
  if(!isset($_SESSION["cart"])) {
    $_SESSION["cart"] = array();
  } else {
    if(count($_SESSION["cart"]) > 0) {
      $cart_empty = FALSE;
      $cart = getCart($_SESSION["cart"]);
    }
  }

  $maxHI = 4;

  /* Generates cart item for dedicated cart page */
  function generateCartItem($item){
    $amalgCost = calculatePrice($item['price'] * $item['amount']);
    echo('
        <td class="imgcol"><img src="'.$item["path"].'" alt="'.$item["alt"].'"></td>
        <td class="namecol">'.$item["name"].'</td>
        <td class="numbercol">
          <input id="item'.$item["product_id"].'amount" type="number" name="count" class="standardInput number" value="'.$item["amount"].'" onchange="updateAmount('.$item["product_id"].',this.value)" onblur="resetAmount('.$item["product_id"].', this)" />
        </td>
        <td class="cancelcol"><button type="button" class="red" onclick="removeItem('.$item["product_id"].')">X</button></td>
        <td class="pricecol">&euro;<span class="cartUpdatable item'.$item["product_id"].' eur">'.$amalgCost["price_eur"].'</span>,<span class="cartUpdatable item'.$item["product_id"].' cent">'.sprintf("%02d", $amalgCost["price_cent"]).'</span></td>
    ');
  }

  function incart($itemID){
    global $cart, $cart_empty;
    if(!$cart_empty && isset($cart[$itemID])){
      return $cart[$itemID]["amount"];
    }
    return 0;
  }

  /* Generates header cart */
  function genHCart(){
    global $cart_empty, $cart;
    if($cart_empty){
      print("<li>
              <div class='popCartItem row'>
                <span class='cartNotice ch-12'>Winkelwagen leeg</span>
              </div>
             </li>");
    } else {
      global $maxHI;
      $i = 0;
      foreach($cart as $item) {
        if($i < $maxHI){
          $i++;
          print("<li class='first'>
            <a href='product.php?product_id=".$item['product_id']."'>
              <div class='popCartItem actionElem row'>
                <div class='popCartIMGW'>
                  <img class='popCartIMG' src='".$item['path']."' />
                </div>
                <div class='popCartDesc'>".$item['name']." x".$item['amount']."</div>
              </div>
            </a>
          </li>");
        } else {
          print("<a href='winkelwagen.php'><img src='./resources/dots.svg' class='centered' /></a>");
          break;
        }
      }
      print("<a class='green popCartCheckout' href='winkelwagen.php'>Afrekenen</a>");
    }
  }

  /* Returns total price of all items in cart in the now standard [price, price_eur, price_cent] format */
  function getTotalPrice($cart){
    $result = array();
    $result["price"] = 0;
    foreach($cart as $item){
      $result["price"] += $item["price"] * $item["amount"];
    }
    $result = calculatePrice($result["price"]);
    return $result;
  }

  /* Returns array in XML format */
  function arrayToXML($array) {
    return arrayToXMLREC($array, new SimpleXMLElement("<?xml version=\"1.0\"?><array></array>"));
  }

  function arrayToXMLREC($array, &$xml){
    foreach($array as $key => $value){
        if(is_array($value)){
            if(is_numeric($key)){
              $key = "item$key";
            }
            $subnode = $xml->addChild($key);
            arrayToXMLREC($value, $subnode);
        }
        else {
            if(is_numeric($key)){
              $key = "item$key";
            }
            $xml->addChild($key, $value);
        }
    }
    return $xml;
  }

  function xmlToArray($xml){
    $array = array();
    $prefix = "item";
    foreach($xml->children() as $child => $childvalue){
      $iname = $childvalue->getName();
      if (substr($iname, 0, strlen($prefix)) == $prefix) {
          $iname = substr($iname, strlen($prefix));
      }
      if(count($childvalue->children()) == 0){
        $array[$iname] = strval($childvalue);
      } else {
        $array[$iname] = xmlToArray($childvalue);
      }
    }
    return $array;
  }

  function generateCartFooter(){
    global $cart;
    global $order;
    print("<div class='row'>
        <div class='costs c-12'>
          <table class='costs-info'>
            <tr>
              <td class='deliverycosts'>Verzendkosten</td>
              <td class='freedelivery'>Gratis</td>
            </tr>
            <tr>
              <td class='totalcosts'>Totaalbedrag<br /><em>inclusief BTW</em></td>
              <td>&euro;<span class='cartUpdatable cart eur'>".(getTotalPrice($cart)['price_eur'])."</span>,<span class='cartUpdatable cart cent'>".(getTotalPrice($cart)['price_cent'])."</span></td>
            </tr>
          </table>
        </div>
      </div>
      <hr class='separator'/>
      <br />
      <div class='row'>
        <div class='orderoptions c-12'>
          <form  method='post' action='".(htmlspecialchars($_SERVER['PHP_SELF']))."'>
              <h2>Bezorging</h2>
              <table>
                <tr>
                  <td><input type='radio' name='order' value='deliver' ".(($order=='deliver')?'checked':'')."></td>
                  <td class='ordertext'>Gratis bezorging</td>
                </tr>
                <tr>
                  <td><input type='radio' name='order' value='collect' required='order' ".(($order=='collect')?'checked':'')."></td>
                  <td class='ordertext'>Ophalen bij ons</td>
                  <td class='movesubmit'><input type='submit' name='submit' required='order' value='Bestellen' class='order'></td>
                </tr>
              </table>
              </form>
          </div>
        </div>
      </div>
    </div>
  ");
  }

  /* Returns all relevant data on cart contents */
  function getCart($cart){
    $return = array();
    foreach($cart as $item){
        $return[$item["id"]] = getCartItem($item);
    }
    return $return;
  }

  /* Combines DB and cart info on cart item */
  function getCartItem($item){
    $return = array();
    $return = getProduct($item["id"]);
    $return["amount"] = $item["amount"];
    /* Add price of amount of items */
    $return = array_merge($return, calculatePrice($return["price"] * $return["amount"]));
    return $return;
  }

  /* Combines DB and cart info on cart item */
  function getCitem($cart, $id){
    $return = array();
    $return = getProduct($id);
    $return["amount"] = $cart[$id]["amount"];
    return $return;
  }

  /* Returns price of cart item in now standard [price, price_eur, price_cent] format */
  function getPrice($item){
    $totalPrice = $item["price"] * $item["amount"];
    $price["price"] = $totalPrice;
    $price["price_eur"] = floor($totalPrice / 100);
    $price["price_cent"] = $totalPrice["price"] % 100;
    return $price;
  }

  /* Returns all data of product corresponding to product_id */
  function getProductAll($product_id){
    return array_merge(getProduct($product_id), getDetails($product_id));
  }

  /* Returns basic data of product corresponding to product_id */
  function getProduct($product_id){
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT products.product_id, products.name, prices.price, categories.category_id, categories.category_name, media.path, media.name as alt, products.visible as visible
                                  FROM products
                                INNER JOIN categories
                                  ON products.category_id = categories.category_id
                                INNER JOIN products_media
                                  ON products.product_id = products_media.product_id
                                INNER JOIN media
                                  ON products_media.media_id = media.media_id
                                INNER JOIN prices
                                  ON products.product_id = prices.product_id
                                WHERE products.product_id = :product_id
                                ORDER BY prices.price_id DESC
                                LIMIT 1");
    $stmt->bindParam(':product_id', $product_id);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
  }

  /* Returns detailed data of product corresponding to product_id */
  function getDetails($product_id){
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT description, supply, serial_number
                                  FROM products
                                WHERE products.product_id = :product_id
                                LIMIT 1");
    $stmt->bindParam(':product_id', $product_id);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
  }

  /* Returns array of value_ids corresponding to product_id */
  function getSpecId($product_id){
    global $globalDB;
    $stmt = $globalDB->prepare('SELECT value_id
                                  FROM products_specs
                                  WHERE product_id = :product_id');
    $stmt->bindParam(':product_id', $product_id);
    $stmt->execute();
    $spec_id = $stmt->fetchAll();
    return $spec_id;
  }

  /* Returns all relevant spec info corresponding to value_id */
  function getSpec($value_id){
    global $globalDB;
    $stmt = $globalDB->prepare("SELECT spec_name, spec_values.value_char as spec_value
                                  FROM products_specs
                                INNER JOIN specs
                                  ON specs.spec_id = products_specs.spec_id
                                INNER JOIN spec_values
                                  ON spec_values.value_id = products_specs.value_id
                                WHERE products_specs.value_id = :value_id");
    $stmt->bindParam(':value_id', $value_id);
    $stmt->execute();
    $spec_value = $stmt->fetch(PDO::FETCH_ASSOC);
    return $spec_value;
  }

  /* Returns name corresponding to category_id */
  function getCategoryName($category_id){
    global $globalDB;
    $stmt = $globalDB->prepare('SELECT category_name
                                FROM categories
                                WHERE category_id = :category_id');
    $stmt->bindParam(':category_id', $category_id);
    $stmt->execute();
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    return $category;
  }

  /* Returns array containing product_ids in category */
  function getCategoryProducts($category_id){
    global $globalDB;
    $stmt = $globalDB->prepare('SELECT product_id
                                FROM products
                                WHERE category_id = :category_id');

    $stmt->bindParam(':category_id', $category_id);
    $stmt->execute();

    $product_id = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $product_id;
  }

  /* Returns displayed price of product in now standard [price, price_eur, price_cent] format */
  function calculatePrice($price){
    $price = round($price * 1.21);
    $new_price['price_eur'] = floor($price / 100);
    $new_price['price_cent'] = $price % 100;

    if ($new_price['price_cent'] == 0) {
      $new_price['price_cent'] = "-";
    } else {
      $new_price['price_cent'] = sprintf("%02d", $new_price["price_cent"]);
    }
    return $new_price;
  }

  function updateCart($p, $a){
    if($a > 0) {
      $_SESSION["cart"][$p]["id"] = $p;
      $_SESSION["cart"][$p]["amount"] = $a;
    }
  }

  function removeFromCart($p){
    unset($_SESSION["cart"][$p]);
  }

  function doesProductExist($product_id){
    global $globalDB;
    $stmt = $globalDB->prepare('SELECT product_id
                                FROM products
                                WHERE product_id = :product_id AND visible = 1');

    $stmt->bindParam(':product_id', $product_id);
    $stmt->execute();

    $product_id = $stmt->fetch(PDO::FETCH_ASSOC);

    if (empty($product_id['product_id'])) {
      return FALSE;
    } else {
      return TRUE;
    }
  }


  /* Switch for AJAX requests */
  if(isset($_POST["action"])){
    switch($_POST["action"]){
      case "generateAll":
        generateAll();
        break;
      case "generateItem":
        if(isset($_POST["id"])){
          generateCartItem(getCitem($_SESSION["cart"], $_POST["id"]));
        }
        break;
      case "genSmallCart":
        genHCart();
        break;
      case "genXMLItem":
        header('Content-Type: text/xml');
        print arrayToXML(getCartItem($_SESSION["cart"][$_POST["id"]]))->asXML();
        break;
      case "genXMLAll":
        header('Content-Type: text/xml');
        print arrayToXML(getCart($_SESSION["cart"]))->asXML();
        break;
      case "genJSONItem":
        if(isset($_POST["id"])){
            header('Content-Type: application/json');
            print json_encode(getCart($_SESSION["cart"])[$_POST["id"]]);
        }
        break;
      case "genJSONAll":
        header('Content-Type: application/json');
        print json_encode(getCart($_SESSION["cart"]));
        break;
      case "update":
        $product = $_POST["id"];
        $amount = $_POST["amount"];
        updateCart($product, $amount);
        break;
      case "updateAndJSON":
          $product = $_POST["id"];
          $amount = $_POST["amount"];
          updateCart($product, $amount);
          header('Content-Type: application/json');
          print json_encode(getCart($_SESSION["cart"]));
          break;
      case "remove":
        $product = $_POST["id"];
        removeFromCart($product);
        break;
      case "genTotalPriceEur":
        print getTotalPrice(getCart($_SESSION["cart"]))["price_eur"];
        break;
      case "genTotalPriceCent":
        print getTotalPrice(getCart($_SESSION["cart"]))["price_cent"];
        break;
    }
  }
?>
