<!--
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         pagingTools.php
Description;  function pagingSetup sets up pagin on admin pages by calculating count per
              page and determining where the query should start.
Usage;        n/a
-->
<?php
  /* Function pagingSetup sets up paging on admin pages */
  function pagingSetup(&$pagecount, &$count, &$n, &$p, &$npage, &$ppage, &$page, &$perpage, $redirect) {
    $start = 0;
    $pagecount = ceil($count / $perpage);
    $n = false;
    $p = false;
    $npage = 1;
    $ppage = 1;
    if(isset($_GET['page'])) {
      $page = intval(htmlspecialchars($_GET['page']));
      if ($pagecount < $page) {
        header("Location: $redirect?page=$pagecount");
        die();
      } else if ($page < 1) {
        header("Location: $redirect?page=1");
        die();
      } else {
        $start = ($page - 1) * $perpage;
        if($page < $pagecount) {
          $n = true;
          $npage = $page + 1;
        }
        if($page > 1) {
          $p = true;
          $ppage = $page - 1;
        }
        if($page >= $pagecount) {
          $n = false;
        }
        if($page <= 1) {
          $p = false;
        }
      }
    } else {
      header("Location: $redirect?page=1");
      die();
    }
    return $start;
  }
 ?>
