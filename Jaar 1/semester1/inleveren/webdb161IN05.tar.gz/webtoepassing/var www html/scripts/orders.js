function queryOrders() {
    var search = $("#select input[name=search]").val();
    var pay = $("#select input[name=pay]").is(':checked');
    var prep = $("#select input[name=prep]").is(':checked');
    var preps = $("#select input[name=preps]").is(':checked');
    var sent = $("#select input[name=sent]").is(':checked');
    var del = $("#select input[name=del]").is(':checked');
    var canc = $("#select input[name=canc]").is(':checked');
    var action = "searchAdminOrders";
    var dataString = "search=" + search + "&pay=" + pay + "&prep=" + prep + "&preps=" + preps + "&sent=" + sent + "&del=" + del + "&canc=" + canc + "&action=" + action;
    $.post("stools/orderTools.php", dataString, function(result) {
        document.getElementById("orderRows").innerHTML = result;
    });
}
