/*
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         global.php
Description;  General javaScript code mostly governing header popOver visibility
Usage;        n/a
*/
$(document).ready(function() {
    /* Remove items designed for use without javascript */
    $(".noJS").css("display", "none");
    $('.noJSButton').removeAttr("href");
    $('.noJSMSearch').removeClass("noJSMSearch");
    var mobilecutoff = 750;
    /* Close mobile search when view size moves out of mobile zone */
    $(window).on("resize orientationChange", function() {
        var width = $(window).width();

        if (width >= mobilecutoff) {
            $(".mobile").fadeOut(200);
        }
    });
    /* Cose popOvers on click outside one of popOvers */
    $(document).on("mouseup touchstart", function(m) {
        var popOver = $(".popOver");
        var chevrons = $(".navChevron");
        var button = $(".navButton");

        if (!popOver.is(m.target) && popOver.has(m.target).length === 0) {
            popOver.fadeOut(200);
            chevrons.fadeOut(200);
            $(".floatingNavContainer").css('height', 'auto');
        }
    });
    $(document).on("focusout", function(f) {
        var popOver = $(".popOver");
        var chevrons = $(".navChevron");

        popOver.fadeOut(200);
        chevrons.fadeOut(200);
    });
    /* Close search menu on escape press */
    $(document).on("keydown", function(e) {
        var popOver = $(".popOver");
        var chevrons = $(".navChevron");
        var keycode = e.keyCode || e.which;

        if (keycode === 27) {
            popOver.fadeOut(200);
            chevrons.fadeOut(200);
        }
    });
});

/* Open popOver with id pop */
function openPopOver(pop) {
    var popOver = $("#" + pop + "Popup" + ":hidden");
    var chevron = $("#" + pop + "Chevron" + ":hidden");

    popOver.fadeIn(200);
    chevron.fadeIn(200);
}

/* Close popOver with id pop */
function closePopOver(pop) {
    var popOver = $("#" + pop + "Popup");
    var chevron = $("#" + pop + "Chevron");

    popOver.fadeOut(200);
    chevron.fadeOut(200);
}
