/*
Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
Name;         registervalidation.php
Description;  Javascript code for the forms
Usage;        n/a
*/

/* Sets errors in registreren.php */
function seterrors() {
    document.getElementById('firstnameErr').style.display = "none";
    document.getElementById('prefixErr').style.display = "none";
    document.getElementById('surnameErr').style.display = "none";
    document.getElementById('cityErr').style.display = "none";
    document.getElementById('zipErr').style.display = "none";
    document.getElementById('streetErr').style.display = "none";
    document.getElementById('addressErr').style.display = "none";
    document.getElementById('affixErr').style.display = "none";
    document.getElementById('birthdayErr').style.display = "none";
    document.getElementById('telErr').style.display = "none";
    document.getElementById('mailErr').style.display = "none";
    document.getElementById('passwordErr').style.display = "none";
    document.getElementById('repasswordErr').style.display = "none";
}

/* Sets errors in adminwijzigen.php */
function seterrorsedit() {
    document.getElementById('firstnameErr').style.display = "none";
    document.getElementById('prefixErr').style.display = "none";
    document.getElementById('surnameErr').style.display = "none";
    document.getElementById('cityErr').style.display = "none";
    document.getElementById('zipErr').style.display = "none";
    document.getElementById('streetErr').style.display = "none";
    document.getElementById('addressErr').style.display = "none";
    document.getElementById('affixErr').style.display = "none";
    document.getElementById('birthdayErr').style.display = "none";
    document.getElementById('telErr').style.display = "none";
    document.getElementById('mailErr').style.display = "none";
    document.getElementById('levelErr').style.display = "none";
}

/* Sets errors in wijzigwachtwoord.php */
function seterrorspasswd() {
    document.getElementById('passwordErr').style.display = "none";
    document.getElementById('repasswordErr').style.display = "none";
}

/* Sets the errors wijziggegevens.php */
function seterrorsedit2() {
    document.getElementById('firstnameErr').style.display = "none";
    document.getElementById('prefixErr').style.display = "none";
    document.getElementById('surnameErr').style.display = "none";
    document.getElementById('cityErr').style.display = "none";
    document.getElementById('zipErr').style.display = "none";
    document.getElementById('streetErr').style.display = "none";
    document.getElementById('addressErr').style.display = "none";
    document.getElementById('affixErr').style.display = "none";
    document.getElementById('birthdayErr').style.display = "none";
    document.getElementById('telErr').style.display = "none";
    document.getElementById('mailErr').style.display = "none";
}

/* Sets the error in wachtwoordvergeten.php */
function seterrorsmail() {
    document.getElementById('mailErr').style.display = "none";
}

/* Sets the errors in wijzigadres.php */
function seterrorsaddress() {
    document.getElementById('cityErr').style.display = "none";
    document.getElementById('zipErr').style.display = "none";
    document.getElementById('streetErr').style.display = "none";
    document.getElementById('addressErr').style.display = "none";
    document.getElementById('affixErr').style.display = "none";
}

/* Sets the errors in addproduct.php */
function setaddproduct() {
    if (document.getElementById('choosecat').value == "newcat") {
        document.getElementById('catinput').style.display = "block";
    } else {
        document.getElementById('catinput').style.display = "none";
    }
    document.getElementById('catinputErr').style.display = "none";
    document.getElementById('productnameErr').style.display = "none";
    document.getElementById('descripErr').style.display = "none";
    document.getElementById('priceErr').style.display = "none";
    var number = document.getElementById('numberOfSpecs').value;
    for (var i = 0; i < number; i++) {
        document.getElementById('specErr' + i).style.display = "none";
        document.getElementById('specvalueErr' + i).style.display = "none";
    }
}

/* Sets the errors in adminproductwijzigen.php */
function seteditproduct() {
    if (document.getElementById('choosecat').value == "newcat") {
        document.getElementById('catinput').style.display = "block";
    } else {
        document.getElementById('catinput').style.display = "none";
    }
    document.getElementById('catinputErr').style.display = "none";
    document.getElementById('productnameErr').style.display = "none";
    document.getElementById('descripErr').style.display = "none";
    document.getElementById('priceErr').style.display = "none";
    document.getElementById('serialnumberErr').style.display = "none";
    document.getElementById('supplyErr').style.display = "none";
}

/* Validates the input from registreren.php */
function regvalidator() {
    sexChecked();
    fnameValid();
    snameValid();
    pfixValid();
    cityValid();
    zipValid();
    streetValid();
    addressValid();
    affixValid();
    telValid();
    mailValid();
    dateValid();
    passValid();
    samePasswd();
}

/* Checks the input from wijziggegevens.php */
function editdatavalidator() {
    sexChecked();
    fnameValid();
    snameValid();
    pfixValid();
    cityValid();
    zipValid();
    streetValid();
    addressValid();
    affixValid();
    telValid();
    mailValid();
    dateValid();
}

/* Checks the input from wijzigwachtwoord.php */
function editwwvalidator() {
    passValid();
    samePasswd();
}

/* Checks the input from wijzigadres.php */
function editaddressvalidator() {
    cityValid();
    zipValid();
    streetValid();
    addressValid();
    affixValid();
}

/* Checks the input from admingegevens.php */
function editadminvalidator() {
    sexChecked();
    fnameValid();
    snameValid();
    pfixValid();
    cityValid();
    zipValid();
    streetValid();
    addressValid();
    affixValid();
    telValid();
    mailValid();
    dateValid();
    levelValid();
}

/* Checks the input from wachtwoordvergeten.php */
function emailvalidator() {
    mailValid();
}

/* Checks the input from addproduct.php */
function addproductvalidator() {
    if (document.getElementById('choosecat').value == "newcat") {
        catValid();
    }
    productnameValid();
    descripValid();
    var number = document.getElementById('numberOfSpecs').value;
    for (var i = 0; i < number; i++) {
        newspecValid(i);
        newspecvalueValid(i);
    }
    priceValid();
}

/* Checks the input from adminproductwijzigen.php */
function editproductvalidator() {
    if (document.getElementById('choosecat').value == "newcat") {
        catValid();
    }
    productnameValid();
    descripValid();
    var number = document.getElementById('numberOfSpecs').value;
    for (var i = 0; i < number; i++) {
        newspecValid(i);
        newspecvalueValid(i);
    }
    priceValid();
    serialValid();
    supplyValid();
}

/* Checks the sex input */
function sexChecked(sex) {
    if (!document.getElementById('male').checked && !document.getElementById('female').checked) {
        document.getElementById('male').focus();
    }
}

/* Checks if the firstname is valid */
function fnameValid() {
    var fname = document.getElementById('firstname').value;
    /* Checks if the input doesn't contain digits */
    var pos = /^([^0-9]*)$/;
    if (fname.length < 2 || !fname.match(pos)) {
        document.getElementById('firstname').style.outlineColor = "red";
        document.getElementById('firstname').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('firstname').focus();
        document.getElementById('firstnameErr').style.display = "block";
    } else {
        document.getElementById('firstname').style.outlineColor = "#4195FC";
        document.getElementById('firstname').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('firstnameErr').style.display = "none";
    }
}

/* Checks is the surname is valid */
function snameValid() {
    var sname = document.getElementById('surname').value;
    /* Checks if the input doesn't contain digits */
    var pos = /^([^0-9]*)$/;
    if (sname.length < 2 || !sname.match(pos)) {
        document.getElementById('surname').style.outlineColor = "red";
        document.getElementById('surname').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('surname').focus();
        document.getElementById('surnameErr').style.display = "block";
    } else {
        document.getElementById('surname').style.outlineColor = "#4195FC";
        document.getElementById('surname').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('surnameErr').style.display = "none";
    }
}

/* Checks if the prefix is valid if it isn't empty */
function pfixValid() {
    /* Checks if the input doesn't contain digits */
    var pos = /^([^0-9]*)$/;
    var pfix = document.getElementById('prefix').value;
    if (pfix.length > 0 && !pfix.match(pos)) {
        document.getElementById('prefix').style.outlineColor = "red";
        document.getElementById('prefix').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('prefix').focus();
        document.getElementById('prefixErr').style.display = "block";
    } else {
        document.getElementById('prefix').style.outlineColor = "#4195FC";
        document.getElementById('prefix').style.border = "2px inset #DADADA";
        document.getElementById('prefixErr').style.display = "none";
    }
}

/* Checks if the cityname is valid */
function cityValid() {
    var city = document.getElementById('city').value;
    /* Checks if the input doesn't contain digits */
    var pos = /^([^0-9]*)$/;
    if (city.length > 0 && city.match(pos)) {
        document.getElementById('city').style.outlineColor = "#4195FC";
        document.getElementById('city').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('cityErr').style.display = "none";
    } else {
        document.getElementById('city').style.outlineColor = "red";
        document.getElementById('city').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('city').focus();
        document.getElementById('cityErr').style.display = "block";
    }
}

/* Checks if the zip is valid */
function zipValid() {
    var zip = document.getElementById('zip').value;
    /* Check for a dutch zip code */
    var pos = /^[1-9][0-9]{3}[\s]?[A-Za-z]{2}$/i;
    if (zip.length > 0 && zip.match(pos)) {
        document.getElementById('zip').style.outlineColor = "#4195FC";
        document.getElementById('zip').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('zipErr').style.display = "none";
    } else {
        document.getElementById('zip').style.outlineColor = "red";
        document.getElementById('zip').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('zip').focus();
        document.getElementById('zipErr').style.display = "block";
    }
}

/* Checks if the streetname is valid */
function streetValid() {
    var street = document.getElementById('street').value;
    /* Checks if the input doesn't contain digits */
    var pos = /^([^0-9]*)$/;
    if (street.length > 0 && street.match(pos)) {
        document.getElementById('street').style.outlineColor = "#4195FC";
        document.getElementById('street').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('streetErr').style.display = "none";
    } else {
        document.getElementById('street').style.outlineColor = "red";
        document.getElementById('street').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('street').focus();
        document.getElementById('streetErr').style.display = "block";
    }
}

/* Checks if the housenumber is valid */
function addressValid() {
    var address = document.getElementById('address').value;
    /* Checks if the input only contains digits */
    var pos = /^[0-9]+$/;
    if (address.length > 0 && address.match(pos)) {
        document.getElementById('address').style.outlineColor = "#4195FC";
        document.getElementById('address').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('addressErr').style.display = "none";
    } else {
        document.getElementById('address').style.outlineColor = "red";
        document.getElementById('address').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('address').focus();
        document.getElementById('addressErr').style.display = "block";
    }
}

/* Check for the affix */
function affixValid() {
    document.getElementById('affix').style.outlineColor = "#4195FC";
    document.getElementById('affix').style.border = "2px inset #DADADA";
    document.getElementById('register').disabled = false;
    document.getElementById('affixErr').style.display = "none";
}

/* Checks if the telephone number is valid */
function telValid() {
    var tel = document.getElementById('tel').value;
    /* Two regexes to check telephone numbers */
    var pos1 = /^(((0)[1-9]{2}[0-9][-]?[1-9][0-9]{5})|((\\+31|0|0031)[1-9][0-9][-]?[1-9][0-9]{6}))$/;
    var pos2 = /^(((\\+31|0|0031)6){1}[1-9]{1}[0-9]{7})$/i;
    if (tel.length > 0 && (tel.match(pos1) || tel.match(pos2))) {
        document.getElementById('tel').style.outlineColor = "#4195FC";
        document.getElementById('tel').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('telErr').style.display = "none";
    } else {
        document.getElementById('tel').style.outlineColor = "red";
        document.getElementById('tel').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('tel').focus();
        document.getElementById('telErr').style.display = "block";
    }
}

/* Checks if the email is valid */
function mailValid() {
    var mail = document.getElementById('email').value;
    /* Regex for emails */
    var pos = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (mail.length > 0 && mail.match(pos)) {
        document.getElementById('email').style.outlineColor = "#4195FC";
        document.getElementById('email').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('mailErr').style.display = "none";
    } else {
        document.getElementById('email').style.outlineColor = "red";
        document.getElementById('email').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('email').focus();
        document.getElementById('mailErr').style.display = "block";
    }
}

/* Checks if the date is valid */
function dateValid() {
    var date = document.getElementById('birthday').value;
    if (date.length == 10) {
        var valid = true;
        var split = date.replace(/-/g, '')
        if (split.length == 8) {
            var day = parseInt(split.substring(0, 2), 10);
            var month = parseInt(split.substring(2, 4), 10);
            var year = parseInt(split.substring(4, 8), 10);

            if ((month < 1) || (month > 12)) {
                valid = false;
            } else if ((day < 1) || (day > 31)) {
                valid = false;
            } else if (((month == 4) || (month == 6) || (month == 9) || (month == 11)) && (day > 30)) {
                valid = false;
            } else if ((month == 2) && (((year % 400) == 0) || ((year % 4) == 0)) && ((year % 100) != 0) && (day > 29)) {
                valid = false;
            } else if ((month == 2) && ((year % 100) == 0) && (day > 29)) {
                valid = false;
            } else if ((month == 2) && (day > 28)) {
                valid = false
            }
            if (valid == false) {
                document.getElementById('birthday').style.outlineColor = "red";
                document.getElementById('birthday').style.border = "2px inset red";
                document.getElementById('register').disabled = true;
                document.getElementById('birthday').focus();
                document.getElementById('birthdayErr').style.display = "block";
            } else {
                document.getElementById('birthday').style.outlineColor = "#4195FC";
                document.getElementById('birthday').style.border = "2px inset #DADADA";
                document.getElementById('register').disabled = false;
                document.getElementById('birthdayErr').style.display = "none";
            }
        }
    } else {
        document.getElementById('birthday').style.outlineColor = "red";
        document.getElementById('birthday').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('birthday').focus();
        document.getElementById('birthdayErr').style.display = "block";
    }
}

/* Checks is the password is valid */
function passValid() {
    var passwd = document.getElementById('password').value;
    if (passwd.length < 8) {
        document.getElementById('password').style.outlineColor = "red";
        document.getElementById('password').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('password').focus();
        document.getElementById('passwordErr').style.display = "block";
    } else {
        document.getElementById('password').style.outlineColor = "#4195FC";
        document.getElementById('password').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('passwordErr').style.display = "none";
    }
}

/* Checks if the two passwords are the same */
function samePasswd() {
    var pass1 = document.getElementById('password').value;
    var pass2 = document.getElementById('repassword').value;
    if (pass1 == pass2) {
        document.getElementById('repassword').style.outlineColor = "#4195FC";
        document.getElementById('repassword').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('repasswordErr').style.display = "none";
    } else {
        document.getElementById('repassword').style.outlineColor = "red";
        document.getElementById('repassword').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('repassword').focus();
        document.getElementById('repasswordErr').style.display = "block";
    }
}

/* Checks if the privilege level is valid */
function levelValid() {
    var level = document.getElementById('level').value;
    if (level.length > 0) {
        if (level >= 0 && level <= 9) {
            document.getElementById('level').style.outlineColor = "#4195FC";
            document.getElementById('level').style.border = "2px inset #DADADA";
            document.getElementById('register').disabled = false;
            document.getElementById('levelErr').style.display = "none";
        } else {
            document.getElementById('level').style.outlineColor = "red";
            document.getElementById('level').style.border = "2px inset red";
            document.getElementById('register').disabled = true;
            document.getElementById('level').focus();
            document.getElementById('levelErr').style.display = "block";
        }
    } else {
        document.getElementById('level').style.outlineColor = "red";
        document.getElementById('level').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('level').focus();
        document.getElementById('levelErr').style.display = "block";
    }
}

/* Opens the categoryname input field when 'new category' is selected */
function opencatinput() {
    var input = document.getElementById('choosecat').value;
    /* Tests if the selected option is 'newcat' */
    if (input == "newcat") {
        document.getElementById('catinput').style.display = "block";
        document.getElementById('catinput').required = true;
    } else {
        document.getElementById('catinput').required = false;
        document.getElementById('catinput').style.display = "none";
        document.getElementById('catinputErr').style.display = "none";
        document.getElementById('register').disabled = false;
        document.getElementById('catinput').style.outlineColor = "#4195FC";
        document.getElementById('catinput').style.border = "2px inset #DADADA";
    }
}

/* Checks if the new category is valid */
function catValid() {
    var cat = document.getElementById('catinput').value;
    if (cat.length < 2) {
        document.getElementById('catinput').style.outlineColor = "red";
        document.getElementById('catinput').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('catinput').focus();
        document.getElementById('catinputErr').style.display = "block";
    } else {
        document.getElementById('catinput').style.outlineColor = "#4195FC";
        document.getElementById('catinput').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('catinputErr').style.display = "none";
    }
}

/* Checks if the productname is valid */
function productnameValid() {
    var pname = document.getElementById('productname').value;
    if (pname.length < 2) {
        document.getElementById('productname').style.outlineColor = "red";
        document.getElementById('productname').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('productname').focus();
        document.getElementById('productnameErr').style.display = "block";
    } else {
        document.getElementById('productname').style.outlineColor = "#4195FC";
        document.getElementById('productname').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('productnameErr').style.display = "none";
    }
}

/* Checks if the description is valid */
function descripValid() {
    var descrip = document.getElementById('descrip').value;
    if (descrip.length < 2) {
        document.getElementById('descrip').style.outlineColor = "red";
        document.getElementById('descrip').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('descrip').focus();
        document.getElementById('descripErr').style.display = "block";
    } else {
        document.getElementById('descrip').style.outlineColor = "#4195FC";
        document.getElementById('descrip').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('descripErr').style.display = "none";
    }
}

/* Checks if the price is valid */
function priceValid() {
    var price = document.getElementById('price').value;
    /* Regex for prices */
    var pos = /^\d+(,\d{2})?$/g;
    if (price.length < 4 || !price.match(pos)) {
        document.getElementById('price').style.outlineColor = "red";
        document.getElementById('price').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('price').focus();
        document.getElementById('priceErr').style.display = "block";
    } else {
        document.getElementById('price').style.outlineColor = "#4195FC";
        document.getElementById('price').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('priceErr').style.display = "none";
    }
}

/* Checks if the serial number is valid */
function serialValid() {
    var ser = document.getElementById('serial_number').value;
    if (ser.length < 1) {
        document.getElementById('serial_number').style.outlineColor = "red";
        document.getElementById('serial_number').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('serial_number').focus();
        document.getElementById('serialnumberErr').style.display = "block";
    } else {
        document.getElementById('serial_number').style.outlineColor = "#4195FC";
        document.getElementById('serial_number').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('serialnumberErr').style.display = "none";
    }
}

/* Checks if the supply is valid */
function supplyValid() {
    var supply = document.getElementById('supply').value;
    var pos = /^[0-9]+$/;
    if (supply.length > 0 && supply.match(pos)) {
        document.getElementById('supply').style.outlineColor = "#4195FC";
        document.getElementById('supply').style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('supplyErr').style.display = "none";
    } else {
        document.getElementById('supply').style.outlineColor = "red";
        document.getElementById('supply').style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('supply').focus();
        document.getElementById('supplyErr').style.display = "block";
    }
}

/* Checks if the specname is valid */
function newspecValid(x) {
    var spec = document.getElementById('spec' + x).value;
    if (spec.length < 2) {
        document.getElementById('spec' + x).style.outlineColor = "red";
        document.getElementById('spec' + x).style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('spec' + x).focus();
        document.getElementById('specErr' + x).style.display = "block";
    } else {
        document.getElementById('spec' + x).style.outlineColor = "#4195FC";
        document.getElementById('spec' + x).style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('specErr' + x).style.display = "none";
    }
}

/* Checks if the specvalue is valid */
function newspecvalueValid(x) {
    var specvalue = document.getElementById('specvalue' + x).value;
    if (specvalue.length < 1) {
        document.getElementById('specvalue' + x).style.outlineColor = "red";
        document.getElementById('specvalue' + x).style.border = "2px inset red";
        document.getElementById('register').disabled = true;
        document.getElementById('specvalue' + x).focus();
        document.getElementById('specvalueErr' + x).style.display = "block";
    } else {
        document.getElementById('specvalue' + x).style.outlineColor = "#4195FC";
        document.getElementById('specvalue' + x).style.border = "2px inset #DADADA";
        document.getElementById('register').disabled = false;
        document.getElementById('specvalueErr' + x).style.display = "none";
    }
}

/* Adds two input fields to the spec table */
function addInput() {
    var number = document.getElementById('numberOfSpecs').value;

    /* Rows to add */
    var rownumber = parseInt(parseInt(number) * 3);
    var row2number = parseInt(rownumber) + 1;
    var row3number = parseInt(row2number) + 1;

    var table = document.getElementById('specsTable');

    /* Insert rows */
    var newrow = table.insertRow(rownumber);
    var specErrRow = table.insertRow(row2number);
    var specvalueErrRow = table.insertRow(row3number);

    /* Insert cells */
    var cell1 = newrow.insertCell(0);
    var cell2 = newrow.insertCell(1);
    var cell3 = specErrRow.insertCell(0);
    var cell4 = specvalueErrRow.insertCell(0);
    var specfield = document.createElement("INPUT");

    /* Spec error row */
    cell3.setAttribute("class", "errorstyle");
    cell3.setAttribute("id", "specErr" + number);
    cell3.innerHTML = "Ongeldige specificatie";
    document.getElementById('specErr' + number).style.display = "none";

    /* Specvalue error row */
    cell4.setAttribute("class", "errorstyle");
    cell4.setAttribute("id", "specvalueErr" + number);
    cell4.innerHTML = "Ongeldige specificatiewaarde";
    document.getElementById('specvalueErr' + number).style.display = "none";

    /* Spec input field */
    specfield.setAttribute("class", "movespecs2");
    specfield.setAttribute("id", "spec" + number);
    specfield.setAttribute("name", "spec" + number);
    specfield.setAttribute("type", "text");
    specfield.setAttribute("placeholder", "Dichtheid kg*m^-3");
    specfield.setAttribute("onkeyup", "newspecValid(" + number + ")");
    specfield.setAttribute("onchange", "newspecValid(" + number + ")");
    specfield.setAttribute("onclick", "newspecValid(" + number + ")");

    /* Specvalue input field */
    var specvaluefield = document.createElement("INPUT");
    specvaluefield.setAttribute("class", "movespecs");
    specvaluefield.setAttribute("id", "specvalue" + number);
    specvaluefield.setAttribute("name", "specvalue" + number);
    specvaluefield.setAttribute("type", "text");
    specvaluefield.setAttribute("placeholder", "12,55");
    specvaluefield.setAttribute("onkeyup", "newspecvalueValid(" + number + ")");
    specvaluefield.setAttribute("onchange", "newspecvalueValid(" + number + ")");
    specvaluefield.setAttribute("onclick", "newspecvalueValid(" + number + ")");

    /* Add input fields to cells */
    cell1.appendChild(specfield);
    cell2.appendChild(specvaluefield);

    /* Adds 1 the value of numberOfSpecs */
    var newnumber = parseInt(parseInt(number) + 1);
    document.getElementById('numberOfSpecs').value = newnumber;
}

/* Removes spec and specvalue field */
function removeInput() {
    var inputnumber = document.getElementById('numberOfSpecs').value;
    if (parseInt(inputnumber) > 1) {
        var newnumber = parseInt(parseInt(inputnumber) - 1);
        var number = parseInt(parseInt(inputnumber) * 3);

        /* Rows to remove */
        var rowtoremove = parseInt(parseInt(number) - 1);
        var rowtoremove2 = parseInt(parseInt(number) - 2);
        var rowtoremove3 = parseInt(parseInt(number) - 3);

        /* Removes rows */
        document.getElementById('specsTable').deleteRow(rowtoremove);
        document.getElementById('specsTable').deleteRow(rowtoremove2);
        document.getElementById('specsTable').deleteRow(rowtoremove3);

        /* Decrease the value in numberOfSpecs with 1 */
        document.getElementById('numberOfSpecs').value = newnumber;
    }
}
