/*
 * Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
 * Name;         search.js
 * Description;  Contains functions to search products and users.
 * Usage; n/a
/*

/* Set up URL to use with database query */
function startSearch(str, url, type) {
    str = str.replace(/\n/g, " ");
    url = url + "?q=" + str;
    url = url + "&sid=" + Math.random();

    $(".search" + type).load(url);
}

/* Products search */
function getProd(str) {
    /* Change layout with empty search string */
    if (str.length == 0) {
        closePopOver("search");
        $("#searchProdM").empty();
    } else {
        var url = "queryResultProd.php",
            type = "Prod";

        startSearch(str, url, type);
    }
}

/* Surname search (admin panel) */
function getNames(str) {
    if (str.length == 0) {
        var elemsel = document.getElementsByName('user_rowsel'),
            elemall = document.getElementsByName('user_rowall');

        for (var i = 0; i < elemsel.length; i++) {
            elemsel[i].style.display = "none";
        }
        for (var i = 0; i < elemall.length; i++) {
            elemall[i].style.display = "table-row";
        }
        document.getElementById('switchpage').style.display = "block";

    } else {
        var elemsel = document.getElementsByName('user_rowsel'),
            elemall = document.getElementsByName('user_rowall'),
            url = "queryResultAdminUsers.php",
            type = "Names";

        for (var i = 0; i < elemsel.length; i++) {
            elemsel[i].style.display = "table-row";
        }
        for (var i = 0; i < elemall.length; i++) {
            elemall[i].style.display = "none";
        }
        document.getElementById('switchpage').style.display = "none";
        startSearch(str, url, type);
    }
}

/* Products search (admin panel) */
function getProducts(str) {
    if (str.length == 0) {
        var elemsel = document.getElementsByName('product_rowsel'),
            elemall = document.getElementsByName('product_rowall');

        for (var i = 0; i < elemsel.length; i++) {
            elemsel[i].style.display = "none";
        }
        for (var i = 0; i < elemall.length; i++) {
            elemall[i].style.display = "table-row";
        }
        document.getElementById('switchpage').style.display = "block";

    } else {
        var elemsel = document.getElementsByName('product_rowsel'),
            elemall = document.getElementsByName('product_rowall'),
            url = "queryResultAdminProducts.php",
            type = "Products";

        for (var i = 0; i < elemsel.length; i++) {
            elemsel[i].style.display = "table-row";
        }
        for (var i = 0; i < elemall.length; i++) {
            elemall[i].style.display = "none";
        }
        document.getElementById('switchpage').style.display = "none";
        startSearch(str, url, type);
    }
}
