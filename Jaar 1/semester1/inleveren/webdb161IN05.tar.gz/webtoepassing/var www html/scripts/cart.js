/*
 * Authors;      Jens Kalshoven, Rico Hoegee, Pim Hordijk, Frederick Kreuk en Sander Hansen
 * Name;         cart.js
 * Description;  functions for implementation of dynamicly updating cart
 * Usage;        n/a
 */

/* Convert an object to an array for easy looping */
function objectToArray(object) {
    return Object.keys(object).map(function (key) {return object[key]});
}

/* Update cart display after cart change */
function updateDisplay(items) {
    for (i = 0; i < items.length; i++) {
        /* If amount smaller than 1, remove product from cart */
        if (items[i]["amount"] < 1) {
            removeItem(items[i]["product_id"]);
        } else {
            /* Update prices of products */
            var itemClass = "item" + items[i]["product_id"];
            [].forEach.call((document.getElementsByClassName("cartUpdatable " + itemClass + " eur")), function(update) {
                update.innerHTML = items[i]["price_eur"];
            });
            [].forEach.call((document.getElementsByClassName("cartUpdatable " + itemClass + " cent")), function(update) {
                update.innerHTML = items[i]["price_cent"];
            });
        }
    }
    /* Update total price */
    [].forEach.call((document.getElementsByClassName("cartUpdatable " + "cart" + " eur")), function(update) {
        $.post("stools/cartTools.php", "action=genTotalPriceEur", function(eur) {
            update.innerHTML = eur;
        });
    });
    [].forEach.call((document.getElementsByClassName("cartUpdatable " + "cart" + " cent")), function(update) {
        $.post("stools/cartTools.php", "action=genTotalPriceCent", function(cent) {
            update.innerHTML = cent;
        });
    });
}

/* Update the header cart */
function updateSmallCart(cart) {
    $.post("stools/cartTools.php", "action=" + "genSmallCart", function(result) {
        document.getElementById("popCart").innerHTML = result;
    });
}

/* Update an item after amount change */
function refreshItem(id, updateID) {
    $.post("stools/cartTools.php", "action=" + "genXMLAll", function(result) {
        items = cartXMLToArray(result);
        updateDisplay(items);
    });
}

/* Update amount of an item in cart through AJAX post request */
function updateAmount(id, amount) {
    if (amount) {
        $.post("stools/cartTools.php", "id=" + id + "&amount=" + amount + "&action=" + "updateAndJSON", function(result) {
            var items = objectToArray(result);
            updateDisplay(items);
        });
    }
}

/* Calculate total price of cart items */
function calcTotalPrice(items) {
    var totalPrice = 0;
    for (i = 0; i < items.length; i++) {
        totalPrice += items[i]["price"] * items[i]["amount"];
    }
    totalPrice = Math.round(totalPrice * 1.21);
    var result = new Array();
    result["price"] = totalPrice;
    result["price_eur"] = Math.floor(totalPrice / 100);
    result["price_cent"] = totalPrice % 100;
    if (result["price_cent"] == 0) {
        result["price_cent"] = "-";
    }
    return result;
}

/* Clean up amount input field after it loses focus to clean up any malformed input */
function resetAmount(id, input) {
    if (input.value == "" || parseInt(input.value) < 1) {
        $.ajax({
            type: "POST",
            url: "stools/cartTools.php",
            data: "id=" + id + "&action=" + "genJSONItem",
            success: function(result) {
                        input.value = result.amount;
                    },
            fail: function() {
              alert("fail");
            },
            dataType: "json"
        });
    }
    if(!isInt(input.value)) {
        input.value = Math.round(input.value);
    }
}

/* Determine if value is an integer */
var isInt = function(n) { return parseInt(n) === n };

function refreshItem(id, updateID) {
    $.ajax({
        type: "POST",
        url: "stools/cartTools.php",
        data: "action=" + "genJSONAll",
        success: function(result) {
                    var cart = objectToArray(result);
                    updateDisplay(cart);
                },
        dataType: "json"
    });
}

/* Remove item from the cart */
function removeItem(id) {
    $.post("stools/cartTools.php", "id=" + id + "&action=" + "remove", function() {
        document.getElementById("item" + id).innerHTML = "";
        document.getElementById("item" + id).style.display = "none";
        refreshItem(id, "item" + id);
    });
}
