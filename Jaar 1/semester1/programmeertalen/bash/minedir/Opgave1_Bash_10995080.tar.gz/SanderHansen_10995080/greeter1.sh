#Dit script vraagt om de naam en returned een bericht met deze naam
echo What is your name?
read -r naam
echo Hello $naam!