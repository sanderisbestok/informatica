/*
 *	NAAM	: Sander Hansen
 *	CKNUM	: 10995080
 *	Studie	: Informatica
 *	
 *	Deel1.java:
 *	- Dit programma print de naam Sander in ASCII-art. 
 */
public class Deel1 {
	public static void main(String[] args) {
		System.out.println("  _________                  .___            ");
		System.out.println(" /   _____/____    ____    __| _/___________ ");
		System.out.println(" \\_____  \\\\__  \\  /    \\  / __ |/ __ \\_  __ \\");
		System.out.println(" /        \\/ __ \\|   |  \\/ /_/ \\  ___/|  | \\/");
		System.out.println("/_______  (____  /___|  /\\____ |\\___  >__|   ");
		System.out.println("        \\/     \\/     \\/      \\/    \\/   ");
	}
}
