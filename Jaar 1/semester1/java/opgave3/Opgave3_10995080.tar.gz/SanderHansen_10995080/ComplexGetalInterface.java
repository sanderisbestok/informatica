interface ComplexGetalInterface {
    public ComplexGetal telop(ComplexGetal cg);
    public ComplexGetal trekaf(ComplexGetal cg);
    public ComplexGetal vermenigvuldig(ComplexGetal cg);
    public ComplexGetal deel(ComplexGetal cg);
    public ComplexGetal omgekeerde();
}
