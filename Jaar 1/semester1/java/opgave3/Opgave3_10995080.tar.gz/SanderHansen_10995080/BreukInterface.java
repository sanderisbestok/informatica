interface BreukInterface {
    public Breuk telop(Breuk breuk);
    public Breuk trekaf(Breuk breuk);
    public Breuk vermenigvuldig(Breuk breuk);
    public Breuk deel(Breuk breuk);
    public Breuk omgekeerde();
}
